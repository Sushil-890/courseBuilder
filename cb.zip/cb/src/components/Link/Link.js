import React from 'react';

const Link = ({ link }) => {
    return (
        <div className="link">
            <a href={link.url}>{link.url}</a> 
        </div>
    );
};

export default Link;