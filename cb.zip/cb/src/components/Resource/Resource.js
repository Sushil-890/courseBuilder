
import React, { useState } from 'react';
import './Resource.css';

const Resource = ({ resource }) => {
    const [selectedFile, setSelectedFile] = useState(null);

    const handleFileChange = (event) => {
        setSelectedFile(URL.createObjectURL(event.target.files[0]));
    };

    return (
        <div className="resource">
            <p>{resource.name}</p>
            <input type="file" onChange={handleFileChange} />
            {selectedFile && <img src={selectedFile} alt="Selected file" />}
        </div>
    );
};

export default Resource;
