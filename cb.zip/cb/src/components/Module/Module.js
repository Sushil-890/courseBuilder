
import React, { useState } from 'react';
import Resource from '../Resource/Resource';
import Link from '../Link/Link'; 
import './Module.css';

const Module = ({ module, onRename, onDelete, onAddResource, onAddLink }) => {
    const [newResource, setNewResource] = useState('');
    const [newLink, setNewLink] = useState(''); 

    const handleAddResource = () => {
        if (newResource) {
            onAddResource(module.id, newResource);
            setNewResource('');
        }
    };

    const handleAddLink = () => { 
        if (newLink) {
            onAddLink(module.id, newLink);
            setNewLink('');
        }
    };

    return (
        <div className="module">
            <h2>{module.name}</h2>
            <button onClick={() => onRename(module.id)}>Rename</button>
            <button onClick={() => onDelete(module.id)}>Delete</button>
            <br/>
            <div>
                {module.resources.map(resource => (
                    <Resource key={resource.id} resource={resource} />
                ))}
                {module.links.map(link => ( 
                    <Link key={link.id} link={link} />
                ))}
            </div>
            <br/>
            <input 
                type="text" 
                value={newResource} 
                onChange={(e) => setNewResource(e.target.value)} 
                placeholder="type a and click add resource" 
            />
            <button onClick={handleAddResource}>Add Resource</button>
            <br/>
            <input 
                type="text" 
                value={newLink} 
                onChange={(e) => setNewLink(e.target.value)} 
                placeholder="Add new link" 
            />
            
            <button onClick={handleAddLink}>Add Link</button> 
        </div>
    );
};

export default Module;
