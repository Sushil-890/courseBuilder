
import React, { useState } from 'react';
import Module from './components/Module/Module';
import './App.css';

const App = () => {
    const [modules, setModules] = useState([]);
    const [newModuleName, setNewModuleName] = useState('');
   

    const addModule = () => {
        if (newModuleName) {
            setModules([...modules, { id: Date.now(), name: newModuleName, resources: [], links: [] }]); 
            setNewModuleName('');
        }
    };

    const renameModule = (id) => {
        const newModuleName = prompt("Enter new module name"); 
        if (newModuleName) {
            setModules(modules.map(module => {
                if (module.id === id) {
                    return { ...module, name: newModuleName }; 
                }
                return module; 
            }));
        }
    };
    

    const deleteModule = (id) => {
        setModules(modules.filter(module => module.id !== id));
    };

    const addResourceToModule = (moduleId, resource) => {
        setModules(modules.map(module => {
            if (module.id === moduleId) {
                return { ...module, resources: [...module.resources, resource] };
            }
            return module;
        }));
    };
    

    const addLinkToModule = (moduleId, link) => { 
        setModules(modules.map(module => {
            if (module.id === moduleId) {
                return { ...module, links: [...module.links, { id: Date.now(), url: link }] };
            }
            return module;
        }));
    };

    return (
        <div className="app">
            <h1>Course Builder</h1>
            <input 
                type="text" 
                value={newModuleName} 
                onChange={(e) => setNewModuleName(e.target.value)} 
                placeholder="New module name" 
            />
            <button onClick={addModule}>Add Module</button>
            <br/><br/><hr/><br/><br/>
            <div className="modules">
                {modules.map(module => (
                    <Module 
                        key={module.id} 
                        module={module} 
                        onRename={renameModule} 
                        onDelete={deleteModule} 
                        onAddResource={addResourceToModule} 
                        onAddLink={addLinkToModule} 
                    />
                ))}
            </div>
        </div>
    );
};

export default App;
